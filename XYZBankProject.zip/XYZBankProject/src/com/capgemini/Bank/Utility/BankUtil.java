package com.capgemini.Bank.Utility;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class BankUtil {

public static EntityManager getEntityManager() {
		
		return Persistence.createEntityManagerFactory("XYZBankProject").createEntityManager();
	}
	
}

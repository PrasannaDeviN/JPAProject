package com.capgemini.Bank.exceptions;

public class Myexception extends Exception{
	private String status;
	
	public Myexception() {
		this.status="Unable to perform operation on table";
	}
	
	public Myexception(String status) {
		super(status);
	}
	
	public String getStatus() {
		return this.status;
	}

	@Override
	public String toString() {
		return "Myexception [status=" + status + "]";
	}
	
	
}


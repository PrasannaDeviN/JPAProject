package com.capgemini.Bank.Dao;

import com.capgemini.Bank.Entity.BankClient;
import com.capgemini.Bank.exceptions.Myexception;



public interface DaoInt {
	
	public int createAccount(BankClient bean) throws Myexception;
	public double showBalance(int accNum) throws Myexception;
	public double withdraw(int accNum,double withdraw) throws Myexception;
	public double deposit(int accNum,double deposit) throws Myexception;
	public double fundTransfer(int senderAcc ,int receiverAcc, double fund) throws Myexception;
	public String printTransactions(int accNum)throws Myexception;
}



package com.capgemini.Bank.Dao;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.capgemini.Bank.Entity.BankClient;
import com.capgemini.Bank.Utility.BankUtil;
import com.capgemini.Bank.exceptions.Myexception;



public class DaoImp implements DaoInt {
	
	//BankClient bean= new BankClient();
	
	EntityManager entityManager=null;
	
	
	public int createAccount(BankClient bean) throws Myexception {
		
		try{
	
		entityManager=BankUtil.getEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(bean);
		entityManager.getTransaction().commit();	
		}catch(PersistenceException e){
			e.printStackTrace();
		throw new Myexception(e.getMessage());
	}finally {
		entityManager.close();
	}
		return bean.getAccNum();
	}   
     
     
	
	public double showBalance(int accNum)throws Myexception{
		EntityManager entityManager=null;
		try{
			entityManager=BankUtil.getEntityManager();
			entityManager.getTransaction().begin();
			BankClient bean=entityManager.find(BankClient.class,accNum);
			return bean.getBalance();
			
		}catch(PersistenceException e){
			e.printStackTrace();
			throw new Myexception(e.getMessage());
		}finally{
			entityManager.close();
		}

	}

	@Override
	public double deposit(int accNum,double deposit) throws Myexception{
		EntityManager entityManager=null;
		double amt;
		try{
			String s1,s2,s3;
			entityManager=BankUtil.getEntityManager();
			entityManager.getTransaction().begin();
			BankClient bean=entityManager.find(BankClient.class,accNum);
			amt=bean.getBalance()+deposit;
			bean.setBalance(amt);
			
			
			s1=bean.getStrTrans();
			s2="\n The amount deposited is "+deposit;
			s3=s1.concat(s2);
			bean.setStrTrans(s3);
			
			entityManager.merge(bean);
			entityManager.getTransaction().commit();
			
			
		}catch(PersistenceException e){
			e.printStackTrace();
			throw new Myexception(e.getMessage());
		}finally{
			entityManager.close();
		}
		return amt;
	}

	
	
	public double withdraw(int accNum, double withdraw ) throws Myexception
	{
		EntityManager entityManager=null;
		double amt1=0.0;
		
		try{
			String s4,s5,s6;
			entityManager=BankUtil.getEntityManager();
			entityManager.getTransaction().begin();
			BankClient bean=entityManager.find(BankClient.class,accNum);
			amt1=bean.getBalance();
			if(amt1<withdraw)
			{
				System.out.println("Insufficient Balance ");
			}
			else
			{
				
				amt1-=withdraw;
				bean.setBalance(amt1);
				s4=bean.getStrTrans();
				s5="Rs."+withdraw+"is withdrawn";
				s6=s4.concat(s5);
				bean.setStrTrans(s6);
			}
			
			entityManager.merge(bean);
			entityManager.getTransaction().commit();
		}catch(PersistenceException e){
			e.printStackTrace();
			throw new Myexception(e.getMessage());
		}finally{
			entityManager.close();
		}
		return amt1;
		
	}
	
	public double fundTransfer(int senderAcc ,int receiverAcc, double fund)throws Myexception{
		
		double amt2;
		try{
			
		    withdraw(senderAcc, fund);
		    amt2=deposit(receiverAcc,fund);
		    
		 if(amt2<0)
		 {
			 return 0;
			 
		 }
		
	}catch(PersistenceException e){
		e.printStackTrace();
		throw new Myexception(e.getMessage());
	}finally{
		entityManager.close();
	}
	return amt2;
}

	@Override
	public String printTransactions(int accNum)throws Myexception  {
		EntityManager entityManager=null;
		String str;
		try{
			
			entityManager=BankUtil.getEntityManager();
			entityManager.getTransaction().begin();
			BankClient bean=entityManager.find(BankClient.class,accNum);
			str=bean.getStrTrans();
			entityManager.merge(bean);
			entityManager.getTransaction().commit();
			
		}catch(PersistenceException e){
			e.printStackTrace();
			throw new Myexception(e.getMessage());
		}finally{
			entityManager.close();
		}
		return str;
	}
}
      
	

package com.capgemini.Bank.Entity;
import javax.*;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="clientdetails")
public class BankClient {
    @Id
    private int accNum; 
    @NotNull
	private String cname;
    private String address;
    private String phNum;
    private String panNum;
    private String strTrans;
    
    

	double balance;

	public int getAccNum() {
		return accNum;
	}
	
	public void setAccNum(int accNum) {
		this.accNum = accNum;
	}



	public BankClient() {

	}

	

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhNum() {
		return phNum;
	}

	public void setPhNum(String phNum) {
		this.phNum = phNum;
	}

	public String getPanNum() {
		return panNum;
	}

	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getStrTrans() {
		return strTrans;
	}



	public void setStrTrans(String strTrans) {
		this.strTrans = strTrans;
	}
	@Override
	public String toString() {
		return "Client [cname=" + cname + ", address=" + address + ", phNum=" + phNum + ", panNum=" + panNum + "]";
	}

}

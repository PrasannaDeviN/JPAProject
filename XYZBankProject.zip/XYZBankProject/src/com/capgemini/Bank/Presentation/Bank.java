package com.capgemini.Bank.Presentation;

//import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;



import com.capgemini.Bank.Entity.BankClient;
import com.capgemini.Bank.Service.ServImp;
import com.capgemini.Bank.Service.ServiceInt;
import com.capgemini.Bank.exceptions.Myexception;

public class Bank {

	public static void main(String[] args) throws Myexception{
try {
		// TODO Auto-generated method stub
		ServImp s = new ServImp();
		BankClient bean = new BankClient();
		Random r=new Random();
		
		Bank b = new Bank();
		while (true) {
			System.out.println("    Welcome to XYZ Bank    ");
			System.out.println("***************************");
			System.out.println("1. CREATE ACCOUNT ");
			System.out.println("2. SHOW BALANCE");
			System.out.println("3. DEPOSIT");
			System.out.println("4. WITHDRAW");
			System.out.println("5. FUND TRANSFER");
			System.out.println("6. PRINT TRANSACTION");
			System.out.println("7. EXIT");
			Scanner sc = new Scanner(System.in);
			Scanner sc2 = new Scanner(System.in);
			int choice = sc.nextInt();
			String strTrans="Transactions";
			boolean flag;
			switch (choice) {
			case 1:
				int accNum;
				accNum=r.nextInt(1000);
				 
				String name;
				do
				{
				System.out.println("Enter name");
				name=sc2.nextLine();
				flag=(s.isName(name));
				}while(flag==false);
				
				
				String address;
				do
				{
				System.out.println("Enter address");
				 address= sc.next();
				flag=(s.isAddress(address));
				}while(flag==false);
				
				
				String phNum;
				do
				{
				System.out.println("Enter PHONE num");
				 phNum=sc.next();
				flag=s.isPhn(phNum);
				}while(flag==false);
				
				
				String panNum;
				do {
				System.out.println("Enter PAN number");
				 panNum= sc.next();
				flag=(s.isPan(panNum));
				}while(flag==false);
				
				bean.setCname(name);
				bean.setAddress(address);
				bean.setPhNum(phNum);
				bean.setPanNum(panNum);
			    bean.setAccNum(accNum);
			    bean.setStrTrans(strTrans);
                System.out.println("Your account number is "+s.createAccount(bean));
               
                
                break;

			case 2:
				
				System.out.println("Enter Account Number");
				int id = sc.nextInt();
				System.out.println("Your current balance is Rs."+s.showBalance(id));
				break;
               
			case 3:
				int id1;
				System.out.println("Enter the Account Number");
				id1= sc.nextInt();
				System.out.println("Enter the amount to be deposited");
				double deposit = sc.nextDouble();
				System.out.println("Deposited amount is Rs."+s.deposit(id1, deposit));
				break;
			case 4:
				
				System.out.println("Enter the Account Number");
				int id2=sc.nextInt();
				System.out.println("Enter the amount to be withdrawn");
				double withdraw=sc.nextDouble();
				System.out.println("Rs."+s.withdraw(id2, withdraw)+" is withdrawn from your account");
				break;
			case 5:
				
				System.out.println("Enter the Sender's  Account Number");
				int id4=sc.nextInt();
				System.out.println("Enter Receiver's Account Number");
				int id5=sc.nextInt();
				System.out.println("Enter the amount to be transfered");
				double fund=sc.nextDouble();
				System.out.println(s.fundTransfer(id4,id5,fund));
				
				break;
			case 6:
				System.out.println("Enter the account number");
			int id6=sc.nextInt();
			System.out.println(s.printTransactions(id6));
			break;
			
		   default:
				System.out.println("wrong choice");
				break;
				
			}
			
		}
			}catch(Exception me) {
				System.out.println("\n The exception is"+me.getMessage());
	}
}
}
	

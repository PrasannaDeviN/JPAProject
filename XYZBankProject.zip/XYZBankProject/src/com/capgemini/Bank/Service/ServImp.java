package com.capgemini.Bank.Service;




import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.Bank.Dao.DaoImp;
import com.capgemini.Bank.Entity.BankClient;
import com.capgemini.Bank.exceptions.Myexception;


public class ServImp implements ServiceInt {
private DaoImp d= new DaoImp();
	
	public int createAccount(BankClient bean)throws Myexception  {
		// TODO Auto-generated method stub
		
       return d.createAccount(bean);
	}
	public boolean isName(String cname)
	{
		boolean flag=false;
		Pattern pn=Pattern.compile("^[a-zA-Z\\s]*$");
		Matcher mn=pn.matcher(cname);
		if(mn.matches())
		{
			flag=true;
			System.out.println("Valid name!!");
		}
		else
		{
			System.out.println("Enter a valid name!");
		}
		return flag;
		
	}
	public boolean isAddress(String address)
	{
		boolean flag=false;
		Pattern pa=Pattern.compile("(?=,*[0-9])[A-Za-z0-9,\\s]+");
		Matcher ma=pa.matcher(address);
		if(ma.matches())
		{
			System.out.println("Valid Address!!!");
			flag=true;
		}
		else
		{
			System.out.println("Invalid address!! Enter valid address");
		}
		return flag;
	}
	public boolean isPhn(String phNum)
	{
		boolean flag=false;
		Pattern pp=Pattern.compile("^[6-9][0-9]{9}$");
		Matcher mp=pp.matcher(phNum);
		if(mp.matches()) {
			flag=true;
			System.out.println("Valid Phone Number!!");
		}
		else 
		{
			System.out.println("Invalid Phone number!! Enter valid phone number");
			 flag=false;
		}
		return flag;
		}
	public boolean isPan(String panNum)
	{
		boolean flag=false;
		Pattern ppan=Pattern.compile("^[0-9A-Za-z]{10}$");
		Matcher mpan=ppan.matcher(panNum);
		if(mpan.matches()) {
			flag=true;
			System.out.println("Valid PAN number!!");
		}
		else 
		{
			System.out.println("Invalid Pan number!! Enter a valid pan number");
			 flag=false;
		}
		return flag;
		}
	                                                                                                                                     
	
	public double showBalance(int accNum) throws Myexception {
		// TODO Auto-generated method stub
		return d.showBalance(accNum);
        
	}

	 
	
	public double deposit(int accNum, double deposit)throws Myexception  {
		// TODO Auto-generated method stub
       return d.deposit(accNum, deposit);
	}


	
	
	 

	
	public double withdraw(int accNum,double withdraw)throws Myexception{
		// TODO Auto-generated method stub
		return d.withdraw(accNum, withdraw);
		
	}


	public double fundTransfer(int senderAcc,int receiverAcc, double fund)throws Myexception{
	
  return d.fundTransfer(senderAcc,receiverAcc,fund);

	}


	@Override
	public String printTransactions(int accNum)throws Myexception {
		
		return d.printTransactions(accNum);
		
	}

}

package com.capgemini.Bank.Dao;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.Bank.Entity.BankClient;
import com.capgemini.Bank.exceptions.Myexception;

public class DaoImpTest {
   DaoImp dao=new DaoImp();
   BankClient b=null;
   
	
	@Test
	public void testCreateAccount() {
		b=new BankClient();
		b.setAccNum(286);
		b.setCname("DEVI");
		b.setAddress("34,sjfhsd");
		b.setPhNum("9962723088");
		b.setPanNum("PO98UY65RE");
		b.setBalance(200);
		b.setStrTrans("Transactions");
		int n;
		try {
			n = dao.createAccount(b);
			assertEquals(286,n);
		} catch (Myexception e) {
			
			System.out.println("test case failed");
		}
		
		
	}


	/*@Test
	public void testShowBalance() {
		
		double n=0.0;
		try {
			n = dao.showBalance(286);
		} catch (Myexception e) {
			
			e.printStackTrace();
		}
		assertEquals(300.0,n);
	}*/

	@Test
	public void testDeposit() {
		double n=0.0;
		try {
			n = dao.deposit(286, 300.0);
		} catch (Myexception e) {
			
			e.printStackTrace();
		}
		assertEquals(300.0,n);
	
}
}

	/*@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}*/


